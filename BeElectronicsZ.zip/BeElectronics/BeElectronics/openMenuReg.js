function ToReg() {
    document.getElementsByClassName('regFieldContainer')[0].style.display = "block";
}
function closeMenu() {
    document.getElementsByClassName('regFieldContainer')[0].style.display = "none";
}
function openLogMenu() {
    document.getElementsByClassName('LogInContainer')[0].style.display = "block";
}
function closeLogMenu() {
    document.getElementsByClassName('LogInContainer')[0].style.display = "none";
}